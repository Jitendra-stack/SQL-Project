-- Group the orders by date and calculate the average
-- number of pizzas ordered per day


with order_quantity as (select orders.date , sum(cast(order_details.quantity as int)) as quantity 
from orders join order_details 
on orders.order_id=order_details.order_id
group by orders.date)

select round(avg(quantity),2) from order_quantity;
