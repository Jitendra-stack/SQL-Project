-- Calculate the percentage contribution of each 
-- pizza type to total revenue

