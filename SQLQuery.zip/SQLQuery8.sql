-- Determine the distribution of orders by hour of the day


select datepart(hour,time) as hour , count(cast (order_id as int )) as order_count from orders
group by datepart(hour , time) 
order by hour asc;
