-- Identify the highest priced pizza
use pizzahut;

select top 1 pizza_types.name , round(pizzas.price,2)
from  pizza_types join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
order by pizzas.price desc;